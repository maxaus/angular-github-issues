"use strict";

angular
  .module("GitHubApp", ["ngResource", "ngRoute"]);
