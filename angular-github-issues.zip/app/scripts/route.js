"use strict";

angular.module("GitHubApp").config([
    "$routeProvider", "$httpProvider",
    function ($routeProvider, $httpProvider) {
        $routeProvider
            .when("/",
            {
                templateUrl: "/views/issue/issue_list.html",
                controller: "IssueListCtrl"
            })
            .when("/issues/:owner/:repo/:number",
            {
                templateUrl: "/views/issue/issue_details.html",
                controller: "IssueDetailsCtrl"
            }).otherwise(
            {
                redirectTo: "/"
            });
        // push function to the interceptors which will intercept
        // the http responses of the whole application
        $httpProvider.interceptors.push("ErrorHandlerInterceptor");
    }
]);
