"use strict";

/**
 * Web service endpoints.
 */
angular.module("GitHubApp").constant("Endpoints", {
    GIT_HUB_API: "https://api.github.com/"
});
