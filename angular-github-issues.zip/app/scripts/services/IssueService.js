"use strict";

angular.module("GitHubApp").factory("IssueService", [
    "Issues",
    function (Issues) {
        var issueService = {};
        
        issueService.getList = function (owner, repo, page, pageSize, sort) {
            return Issues.list({owner: owner, repo: repo, page: page, per_page: pageSize, sort: sort}).$promise;
        };

        issueService.getIssueDetails = function (owner, repo, number) {
            return Issues.details({owner: owner, repo: repo, number: number}).$promise;
        };
        
        return issueService;
    }
]);