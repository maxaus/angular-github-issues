"use strict";

angular.module("GitHubApp").factory("RepositoryService", [
    "Repositories",
    function (Repositories) {
        var repositoryService = {};

        repositoryService.getByOwner = function (owner) {
            return Repositories.getByOwner({owner: owner}).$promise;
        };

        repositoryService.getRepository = function (owner, repo) {
            return Repositories.details({owner: owner, repo: repo}).$promise;
        };

        return repositoryService;
    }
]);
