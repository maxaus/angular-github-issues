"use strict";

/**
 * Controller for the page with GitHub issue list and search form.
 */
angular.module("GitHubApp")
    .controller("IssueListCtrl", ["$scope", "IssueService", "RepositoryService", function ($scope, IssueService, RepositoryService) {
        // rubinius
        //$scope.owner = "";
        //$scope.repo = "";
        $scope.sortParam = "created";
        $scope.currentPage = 1;
        $scope.pageSize = 10;
        $scope.pageCount = 0;
        $scope.pageSizeOptions = [5, 10, 20];
        $scope.nextPageDisabled = ($scope.currentPage === $scope.pageCount);
        $scope.searchInProgress = false;

        /**
         * Search issues by repository owner name, repo name and pagination parameters.
         */
        $scope.searchIssues = function () {
            $scope.searchInProgress = true;
            // Load repository details first to get count of issues
            //todo: call once
            RepositoryService.getRepository($scope.owner, $scope.repo).then(function (repository) {
                $scope.pageCount = Math.ceil(repository.open_issues_count / $scope.pageSize);
                // Load issue list
                IssueService.getList($scope.owner, $scope.repo, $scope.currentPage, $scope.pageSize, $scope.sortParam).then(function (issueList) {
                    $scope.issueList = issueList;
                    $scope.searchInProgress = false;
                })
            });

        };

        $scope.range = function (n) {
            return new Array(n);
        };

        $scope.loadPage = function (pageNumber) {
            $scope.currentPage = pageNumber;
            $scope.searchIssues();
        };

        $scope.loadNextPage = function () {
            $scope.currentPage++;
            $scope.searchIssues();
        };

        $scope.loadPrevPage = function () {
            $scope.currentPage--;
            $scope.searchIssues();
        };
    }]);
