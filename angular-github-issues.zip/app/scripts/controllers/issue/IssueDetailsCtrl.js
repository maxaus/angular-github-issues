"use strict";

/**
 * Controller for GitHub issue details page.
 */
angular.module("GitHubApp")
    .controller("IssueDetailsCtrl", ["$scope", "$routeParams", "IssueService", function ($scope, $routeParams, IssueService) {

        /**
         * Get selected repo details
         */
        IssueService.getIssueDetails($routeParams.owner, $routeParams.repo, $routeParams.number).then(function(result) {
            $scope.issue = result;
        });
    }]);