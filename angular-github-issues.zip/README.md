# angular-github-repos
Angular SPA for listing GitHub issues
